import { Outlet, Link } from "react-router-dom";
import "./navigasi.css";

const Navigasi = () => {
  return (
    <>
      <section className="container-nav">
        <div className="row ">
          <div className="col-3">
            <Link to="/" className="li">
              <h1>
                <b>
                  <i>Wedding Us</i>
                </b>
              </h1>
            </Link>
          </div>
          <div className="col-5">
            <Link to="/Login" className="li">
              <p className="fitur">Preset/Deasin</p>
            </Link>
            <Link to="/Login" className="li">
              <p className="fitur">Portfolio</p>
            </Link>
            <Link to="/Login" className="li">
              <p className="fitur">Lainnya</p>
            </Link>
          </div>
          <div className="col-4">
            <Link to="/SignUp" className="li">
              <p className="daftar">Daftar</p>
            </Link>
            <Link to="/Login" className="li">
              <p className="daftar">Login</p>
            </Link>
          </div>
        </div>
      </section>

      <Outlet />
    </>
  );
};

export default Navigasi;
