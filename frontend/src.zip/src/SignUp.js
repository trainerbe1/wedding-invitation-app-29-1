import React, { useState } from "react";
import "./SignUp.css";

function SignUp() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    whatsapp: "",
    womanName: "",
    manName: "",
    invitationType: "wedding",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form data submitted:", formData);
  };

  return (
    <div className="registration-page">
      <form className="registration-form" onSubmit={handleSubmit}>
        <h2>Daftar sebagai Individu</h2>
        <div className="form-group">
          <label>
            <input
              type="radio"
              name="invitationType"
              value="wedding"
              checked={formData.invitationType === "wedding"}
              onChange={handleChange}
            />
            Undangan pernikahan
          </label>
          <label>
            <input
              type="radio"
              name="invitationType"
              value="other"
              checked={formData.invitationType === "other"}
              onChange={handleChange}
            />
            Undangan lainnya (khitanan, ulang tahun dsb)
          </label>
        </div>
        <div className="form-group">
          <input
            type="email"
            name="email"
            placeholder="Alamat email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <input
            type="text"
            name="whatsapp"
            placeholder="nomor whatsapp yang aktif"
            value={formData.whatsapp}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <input
            type="text"
            name="womanName"
            placeholder="Nama panggilan wanita"
            value={formData.womanName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <input
            type="text"
            name="manName"
            placeholder="Nama panggilan pria"
            value={formData.manName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>
            <input type="checkbox" required />
            saya menyetujui syarat penggunaan
          </label>
        </div>
        <button type="submit" className="submit-btn">
          Buat Sekarang
        </button>
        <button type="button" className="google-btn">
          Daftar dengan Google
        </button>
        <p>
          Sudah ada akun? <a href="/login">login disini</a>
        </p>
      </form>
    </div>
  );
}

export default SignUp;
