import React from "react";
import "./index.css";
import pernikahanImage from "./img/pernikahan3.png"; // Import gambar pernikahan2.jpg

function HomePage() {
  const pinkSoft = {
    backgroundColor: "#F8F6F0", // kode warna pink soft
    height: "100vh", // tinggi penuh viewport
    display: "flex",
    alignItems: "center",
    justifyContent: "center", // Untuk mengatur rata tengah secara horizontal
  };

  const contentContainer = {
    textAlign: "center", // Mengatur rata tengah untuk teks
    fontFamily: "Arial, sans-serif", // Mengatur jenis font untuk teks
    fontWeight: "bold", // Mengatur ketebalan font
    marginLeft: "15%",
  };

  const imageContainer = {
    marginLeft: "20%",
  };

  const h1Style = {
    color: "#bd1e59", // Warna pink
    fontSize: "48px", // Ukuran font
    fontFamily: "Arial, sans-serif", // Jenis font
    fontWeight: "bold", // Ketebalan font
  };

  const h2Style = {
    fontSize: "24px", // Ukuran font
    fontFamily: "Arial, sans-serif", // Jenis font
    fontWeight: "bold", // Ketebalan font
  };

  const pStyle = {
    fontSize: "16px", // Ukuran font
    fontFamily: "Arial, sans-serif", // Jenis font
    fontWeight: "bold", // Ketebalan font
  };

  return (
    <div id="Homepage">
      <section className="">
        <div style={pinkSoft}>
          <div style={contentContainer}>
            <h1 style={h1Style}>Platform no. 1</h1>
            <h2 style={h2Style}>undangan lebih bagus dan keren</h2>
            <p style={pStyle}>ayo bikin undanganmu sekarang juga!</p>
          </div>

          <div style={imageContainer}>
            <img src={pernikahanImage} alt="Undangan Pernikahan" />
          </div>
        </div>
      </section>
    </div>
  );
}

export default HomePage;
