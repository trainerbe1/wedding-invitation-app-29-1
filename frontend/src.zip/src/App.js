import "bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "./Home-page";
import Navigasi from "./Navigasi";
import Login from "./Login";
import SignUp from "./SignUp";
import NavCustomer from "./customer/NavCustomer";
import Dasboard from "./customer/Dasboardd";
import Undangan from "./customer/Undangan";
import CustomerService from "./customer/CustomerService";
import BuatUndangan from "./customer/BuatUndangan";
import KelolaUndangan from "./customer/KelolaUndangan";
import KelolaPengantin from "./KelolaFitur/KelolaPengantin";

function App() {
  return (
    <div>
      {/* Routes */}
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<NavCustomer />}>
            <Route path="login" element={<Navigasi />} />
            <Route path="homepage" element={<HomePage />} />
            <Route path="login" element={<Login />} />
            <Route path="signup" element={<SignUp />} />
            <Route index element={<Dasboard />} />
            <Route path="undangan" element={<Undangan />} />
            <Route path="customerservice" element={<CustomerService />} />
            <Route path="buatundangan" element={<BuatUndangan />}></Route>
            <Route path="kelolaundangan" element={<KelolaUndangan />}></Route>
            <Route path="kelolapengantin" element={<KelolaPengantin />}></Route>
          </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
